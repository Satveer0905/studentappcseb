const express=require('express')
const app=express();
const PORT=3005;
app.get("/",(req,res)=>
{
    res.send("Welcome to Express Framework");
})
app.post("/",(req,res)=>{
    res.send("hii,Hitting the message /msg api");
})

app.post("/register",(req,res)=>{
    let arr=[]
    const { name ,email,password}=req.body;
    const data1=await fs.readFile('student.json',{encoding:'utf-8'});
                arr=JSON.parse(data1);
})
app.listen(PORT,()=>{
    console.log("Express is running on port "+PORT);
    })